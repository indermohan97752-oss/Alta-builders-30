# Chat app backend

Node + Express + Socket.IO + MongoDB (Mongoose), TypeScript.

## Run

```bash
cp .env.example .env     # then set MONGODB_URI (and a real JWT_SECRET)
npm install
npm run dev              # API on :4000; creates collections, validators and indexes on start
curl localhost:4000/health
```

## Environment (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `MONGODB_URI` | required | e.g. `mongodb://localhost:27017/chat` or an Atlas `mongodb+srv://...` string |
| `JWT_SECRET` | required | signs auth tokens; production refuses the default |
| `PORT` | 4000 | API port |
| `CLIENT_ORIGIN` | http://localhost:5173 | allowed CORS / Socket.IO origin |
| `BCRYPT_ROUNDS` | 12 | password hashing cost |
| `POSTMAN_API_KEY` | optional | only for `npm run postman:sync` |

The database user needs permission to create collections and indexes and to modify collection options (Atlas role `dbAdmin` or `readWrite` plus `dbAdmin`).

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | start with auto-reload |
| `npm run build` / `npm start` | compile to `dist/` and run |
| `npm run db:init` | create collections, validators and indexes without starting the server |
| `npm test` | unit tests (no database) |
| `npm run test:integration` | room CRUD + auth over HTTP; needs MongoDB; uses a `*_test` database that is dropped each run |
| `npm run postman:sync` | push `../docs/postman/chat-app.postman_collection.json` to Postman |

## Layout

```
src/
  app.ts, index.ts, config.ts, db.ts, socket.ts
  db/init.ts            collection validators + indexes
  models/               schemas, user/room/message data access, JSON serializers
  routes/               auth, users, rooms, health
  middleware/           JWT auth, room membership
  services/             password hashing, permissions, realtime helpers
  validation/           zod schemas
  __tests__/            unit tests; integration/ needs MongoDB
scripts/postman-sync.ts
```

Status: written but not yet run or type-checked end to end. Expect small fixes on the first start.
