import { Types } from "mongoose";
import type { Role } from "../services/permissions.js";
import { MessageModel, RoomModel, UserModel } from "./schemas.js";
import { toRoom } from "./serializers.js";
import { isUniqueViolation } from "./user.js";

interface MemberDoc {
  user: Types.ObjectId;
  role: Role;
  joinedAt: Date;
  lastReadMessageId?: Types.ObjectId | null;
  isMuted: boolean;
}
interface RoomDoc {
  _id: Types.ObjectId;
  type: "direct" | "group";
  name?: string | null;
  description?: string | null;
  avatarUrl?: string | null;
  createdBy?: Types.ObjectId;
  createdAt: Date;
  members: MemberDoc[];
}

export interface Membership {
  role: Role;
  type: "direct" | "group";
  is_muted: boolean;
}

const asRoom = (x: unknown) => x as RoomDoc;
const roleOrder: Record<Role, number> = { owner: 0, admin: 1, member: 2 };
const idStr = (x: unknown) => String(x);

export async function getMembership(roomId: string, userId: string): Promise<Membership | null> {
  const room = await RoomModel.findOne({ _id: roomId, "members.user": userId }).select("type members").lean();
  if (!room) return null;
  const me = asRoom(room).members.find((m) => idStr(m.user) === userId)!;
  return { role: me.role, type: room.type as "direct" | "group", is_muted: me.isMuted };
}

/** Rooms list: last message, unread count, and the other person's name for direct chats. */
export async function listRoomsForUser(userId: string) {
  const rooms = (await RoomModel.find({ "members.user": userId }).lean()) as unknown as RoomDoc[];

  const otherIds = rooms
    .filter((r) => r.type === "direct")
    .flatMap((r) => r.members.filter((m) => idStr(m.user) !== userId).map((m) => m.user));
  const others = new Map(
    (await UserModel.find({ _id: { $in: otherIds } }).select("displayName username status").lean()).map((u) => [idStr(u._id), u]),
  );

  const rows = await Promise.all(
    rooms.map(async (r) => {
      const me = r.members.find((m) => idStr(m.user) === userId)!;
      const last = (await MessageModel.findOne({ room: r._id, deletedAt: null })
        .sort({ _id: -1 })
        .populate("sender", "displayName username")
        .lean()) as any;

      const unreadFilter: Record<string, unknown> = { room: r._id, deletedAt: null, sender: { $ne: userId } };
      if (me.lastReadMessageId) unreadFilter._id = { $gt: me.lastReadMessageId };
      const unread = await MessageModel.countDocuments(unreadFilter);

      const otherMember = r.type === "direct" ? r.members.find((m) => idStr(m.user) !== userId) : undefined;
      const other: any = otherMember ? others.get(idStr(otherMember.user)) : undefined;

      return {
        id: idStr(r._id),
        type: r.type,
        name: r.name ?? other?.displayName ?? other?.username ?? null,
        description: r.description ?? null,
        role: me.role,
        is_muted: me.isMuted,
        other_status: other?.status ?? null,
        last_content: last?.content ?? null,
        last_type: last?.type ?? null,
        last_at: last?.createdAt ?? null,
        last_sender: last?.sender ? (last.sender.displayName ?? last.sender.username) : null,
        unread,
        sortKey: last?.createdAt ?? r.createdAt,
      };
    }),
  );
  rows.sort((a, b) => +new Date(b.sortKey) - +new Date(a.sortKey));
  return rows.map(({ sortKey: _omit, ...rest }) => rest);
}

export async function getRoomDetails(roomId: string, viewerId: string) {
  const room = (await RoomModel.findById(roomId).lean()) as unknown as RoomDoc | null;
  if (!room) return null;

  const users = await UserModel.find({ _id: { $in: room.members.map((m) => m.user) } }).lean();
  const byId = new Map(users.map((u) => [idStr(u._id), u]));

  const members = room.members
    .map((m) => {
      const u: any = byId.get(idStr(m.user)) ?? {};
      return {
        user_id: idStr(m.user),
        username: u.username as string,
        display_name: (u.displayName ?? null) as string | null,
        avatar_url: (u.avatarUrl ?? null) as string | null,
        status: (u.status ?? "offline") as "online" | "away" | "offline",
        role: m.role,
        joined_at: m.joinedAt,
      };
    })
    .sort((a, b) => roleOrder[a.role] - roleOrder[b.role] || +new Date(a.joined_at) - +new Date(b.joined_at));

  // A direct chat is named after the other person
  const name =
    room.type === "direct" ? (members.find((m) => m.user_id !== viewerId)?.display_name ?? "Direct chat") : (room.name ?? null);
  return { ...toRoom(room), name, members };
}

export async function createGroup(
  creatorId: string,
  input: { name: string; description?: string | null; memberIds: string[] },
) {
  // Unknown ids are ignored; the creator is never added twice
  const valid = await UserModel.find({ _id: { $in: input.memberIds, $ne: creatorId } }).select("_id").lean();
  const room = await RoomModel.create({
    type: "group",
    name: input.name,
    description: input.description ?? null,
    createdBy: creatorId,
    members: [{ user: creatorId, role: "owner" }, ...valid.map((u) => ({ user: u._id, role: "member" }))],
  });
  return { room: toRoom(room), addedIds: valid.map((u) => idStr(u._id)) };
}

export async function getOrCreateDm(userId: string, otherId: string) {
  const dmKey = [userId, otherId].sort().join(":");
  const existing = await RoomModel.findOne({ dmKey }).lean();
  if (existing) return { room: toRoom(existing), created: false };
  try {
    const room = await RoomModel.create({
      type: "direct",
      dmKey,
      createdBy: userId,
      members: [{ user: userId }, { user: otherId }],
    });
    return { room: toRoom(room), created: true };
  } catch (err) {
    // Two people starting the same chat at once: the unique dmKey index lets one win
    if (!isUniqueViolation(err)) throw err;
    const raced = await RoomModel.findOne({ dmKey }).lean();
    return { room: toRoom(raced), created: false };
  }
}

export async function updateRoom(roomId: string, patch: { name?: string; description?: string | null }) {
  const set: Record<string, unknown> = {};
  if (patch.name !== undefined) set.name = patch.name;
  if (patch.description !== undefined) set.description = patch.description;
  const row = await RoomModel.findByIdAndUpdate(roomId, { $set: set }, { new: true, runValidators: true }).lean();
  return toRoom(row);
}

export async function deleteRoom(roomId: string) {
  // Room first, so a failure part-way leaves hidden orphan messages rather than a visible empty room
  await RoomModel.deleteOne({ _id: roomId });
  await MessageModel.deleteMany({ room: roomId });
}

/** Returns the ids that were actually added (existing members and unknown users are skipped). */
export async function addMembers(roomId: string, userIds: string[]): Promise<string[]> {
  const room = (await RoomModel.findById(roomId).select("members.user").lean()) as unknown as RoomDoc | null;
  if (!room) return [];
  const current = new Set(room.members.map((m) => idStr(m.user)));
  const candidates = userIds.filter((id) => !current.has(id));
  const users = await UserModel.find({ _id: { $in: candidates } }).select("_id").lean();
  const toAdd = users.map((u) => u._id);
  if (!toAdd.length) return [];

  // The $nin guard makes this a no-op if someone else added them in the meantime
  const res = await RoomModel.updateOne(
    { _id: roomId, "members.user": { $nin: toAdd } },
    { $push: { members: { $each: toAdd.map((id) => ({ user: id, role: "member", joinedAt: new Date() })) } } },
  );
  return res.modifiedCount ? toAdd.map(idStr) : [];
}

export async function removeMember(roomId: string, userId: string): Promise<boolean> {
  const res = await RoomModel.updateOne({ _id: roomId, "members.user": userId }, { $pull: { members: { user: userId } } });
  return res.modifiedCount > 0;
}

export async function setRole(roomId: string, userId: string, role: "admin" | "member"): Promise<boolean> {
  const res = await RoomModel.updateOne(
    { _id: roomId, members: { $elemMatch: { user: userId, role: { $ne: "owner" } } } },
    { $set: { "members.$.role": role } },
  );
  return res.modifiedCount > 0;
}

export const setMuted = (roomId: string, userId: string, isMuted: boolean) =>
  RoomModel.updateOne({ _id: roomId, "members.user": userId }, { $set: { "members.$.isMuted": isMuted } });

/** Moves the read marker forward only, never backward. */
export const markRead = (roomId: string, userId: string, messageId: string) =>
  RoomModel.updateOne(
    {
      _id: roomId,
      members: {
        $elemMatch: { user: userId, $or: [{ lastReadMessageId: null }, { lastReadMessageId: { $lt: messageId } }] },
      },
    },
    { $set: { "members.$.lastReadMessageId": messageId } },
  );

/**
 * Leave a group. If the owner leaves, ownership passes to the longest-standing admin
 * (or member). If nobody remains, the room is deleted.
 */
export async function leaveGroup(roomId: string, userId: string) {
  const room = await RoomModel.findById(roomId);
  if (!room) return { left: false as const };
  const idx = room.members.findIndex((m) => idStr(m.user) === userId);
  if (idx < 0) return { left: false as const };

  const wasOwner = room.members[idx].role === "owner";
  room.members.splice(idx, 1);

  if (!room.members.length) {
    await deleteRoom(roomId);
    return { left: true as const, roomDeleted: true, newOwnerId: null as string | null };
  }

  let newOwnerId: string | null = null;
  if (wasOwner) {
    const next = [...room.members].sort(
      (a, b) => Number(b.role === "admin") - Number(a.role === "admin") || +a.joinedAt - +b.joinedAt,
    )[0];
    next.role = "owner";
    newOwnerId = idStr(next.user);
  }
  await room.save();
  return { left: true as const, roomDeleted: false, newOwnerId };
}
