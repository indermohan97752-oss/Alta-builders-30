import { MessageModel, UserModel } from "./schemas.js";
import { toMessage } from "./serializers.js";

/** Newest `limit` messages older than the `before` cursor (a message id), returned oldest-first. */
export async function listMessages(roomId: string, before: string | null, limit: number) {
  const filter: Record<string, unknown> = { room: roomId, deletedAt: null };
  if (before) filter._id = { $lt: before };
  const rows = (await MessageModel.find(filter)
    .sort({ _id: -1 })
    .limit(limit)
    .populate("sender", "displayName username")
    .lean()) as any[];
  return rows.reverse().map((m) => toMessage(m));
}

export async function createMessage(input: {
  room: string;
  sender: string;
  content: string;
  type?: "text" | "system";
  replyTo?: string | null;
}) {
  // A reply must point at a message in the same room
  let replyTo: string | null = input.replyTo ?? null;
  if (replyTo && !(await MessageModel.exists({ _id: replyTo, room: input.room }))) replyTo = null;

  const doc = await MessageModel.create({
    room: input.room,
    sender: input.sender,
    type: input.type ?? "text",
    content: input.content,
    replyTo,
  });
  const sender = await UserModel.findById(input.sender).select("displayName username").lean();
  return toMessage(doc, sender);
}
