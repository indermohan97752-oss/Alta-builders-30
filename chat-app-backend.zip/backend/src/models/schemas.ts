import mongoose, { Schema } from "mongoose";

const ObjectId = Schema.Types.ObjectId;
const BCRYPT = /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/;

// ---------------------------------------------------------------- users
const userSchema = new Schema(
  {
    username: { type: String, required: true, trim: true, match: /^[A-Za-z0-9_]{3,30}$/ },
    usernameLower: { type: String, required: true, unique: true }, // case-insensitive uniqueness
    email: { type: String, required: true, unique: true, lowercase: true, trim: true, maxlength: 255 },
    // select:false means queries never return the hash unless they ask for it explicitly
    passwordHash: { type: String, required: true, select: false, match: [BCRYPT, "passwordHash must be a bcrypt hash"] },
    displayName: { type: String, trim: true, maxlength: 60 },
    avatarUrl: { type: String },
    bio: { type: String, maxlength: 200 },
    status: { type: String, enum: ["online", "away", "offline"], default: "offline" },
    lastSeenAt: { type: Date },
  },
  { collection: "users", timestamps: { createdAt: true, updatedAt: false } },
);
userSchema.pre("validate", function () {
  if (this.username) this.usernameLower = this.username.toLowerCase();
});

// ---------------------------------------------------------------- rooms
// Members are embedded: one read gives a room and everyone in it, and every
// membership change is a single-document (atomic) update.
const memberSchema = new Schema(
  {
    user: { type: ObjectId, ref: "User", required: true },
    role: { type: String, enum: ["owner", "admin", "member"], default: "member" },
    joinedAt: { type: Date, default: Date.now },
    lastReadMessageId: { type: ObjectId, default: null }, // drives unread counts
    isMuted: { type: Boolean, default: false },
  },
  { _id: false },
);

const roomSchema = new Schema(
  {
    type: { type: String, enum: ["direct", "group"], required: true },
    name: { type: String, trim: true, maxlength: 80 },
    description: { type: String, trim: true, maxlength: 255, default: null },
    avatarUrl: { type: String },
    dmKey: { type: String, unique: true, sparse: true }, // sorted "userA:userB"; direct rooms only
    createdBy: { type: ObjectId, ref: "User" },
    members: { type: [memberSchema], default: [] },
  },
  { collection: "rooms", timestamps: { createdAt: true, updatedAt: false } },
);
roomSchema.index({ "members.user": 1 }); // "which rooms is this user in?"

// ------------------------------------------------------------- messages
// Separate collection: messages grow without bound, so they are never embedded.
// ObjectIds are time-ordered, so _id doubles as the pagination cursor.
const messageSchema = new Schema(
  {
    room: { type: ObjectId, ref: "Room", required: true },
    sender: { type: ObjectId, ref: "User", required: true },
    type: { type: String, enum: ["text", "image", "file", "system"], default: "text" },
    content: { type: String, maxlength: 4000 },
    attachmentUrl: { type: String },
    replyTo: { type: ObjectId, ref: "Message", default: null },
    editedAt: { type: Date },
    deletedAt: { type: Date },
  },
  { collection: "messages", timestamps: { createdAt: true, updatedAt: false } },
);
messageSchema.index({ room: 1, _id: -1 }); // latest messages in a room, newest first

export const UserModel = mongoose.model("User", userSchema);
export const RoomModel = mongoose.model("Room", roomSchema);
export const MessageModel = mongoose.model("Message", messageSchema);
