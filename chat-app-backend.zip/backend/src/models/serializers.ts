/** Mongo documents -> the JSON shape the API has always returned. passwordHash is never included. */

export const toPublicUser = (u: any) => ({
  id: String(u._id),
  username: u.username as string,
  email: u.email as string,
  display_name: (u.displayName ?? null) as string | null,
  avatar_url: (u.avatarUrl ?? null) as string | null,
  bio: (u.bio ?? null) as string | null,
  status: u.status as "online" | "away" | "offline",
  created_at: u.createdAt as Date,
});

export const toUserLite = (u: any) => ({
  id: String(u._id),
  username: u.username as string,
  display_name: (u.displayName ?? null) as string | null,
  avatar_url: (u.avatarUrl ?? null) as string | null,
  status: u.status as "online" | "away" | "offline",
});

export const toRoom = (r: any) => ({
  id: String(r._id),
  type: r.type as "direct" | "group",
  name: (r.name ?? null) as string | null,
  description: (r.description ?? null) as string | null,
  avatar_url: (r.avatarUrl ?? null) as string | null,
  created_by: r.createdBy ? String(r.createdBy) : null,
  created_at: r.createdAt as Date,
});

export const toMessage = (m: any, sender?: any) => {
  const s = sender ?? (typeof m.sender === "object" && m.sender?.username ? m.sender : null);
  return {
    id: String(m._id),
    room_id: String(m.room),
    sender_id: String(s?._id ?? m.sender),
    sender_name: s ? ((s.displayName ?? s.username) as string) : null,
    type: m.type as "text" | "image" | "file" | "system",
    content: (m.content ?? null) as string | null,
    attachment_url: (m.attachmentUrl ?? null) as string | null,
    reply_to_id: m.replyTo ? String(m.replyTo) : null,
    created_at: m.createdAt as Date,
    edited_at: (m.editedAt ?? null) as Date | null,
  };
};
