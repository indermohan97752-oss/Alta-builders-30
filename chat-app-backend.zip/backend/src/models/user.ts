import { Types } from "mongoose";
import { MessageModel, RoomModel, UserModel } from "./schemas.js";
import { toPublicUser, toUserLite } from "./serializers.js";

export type PublicUser = ReturnType<typeof toPublicUser>;
export type UserLite = ReturnType<typeof toUserLite>;

export interface NewUser {
  username: string;
  email: string;
  /** A bcrypt hash. This type has no plaintext password field on purpose. */
  passwordHash: string;
  displayName: string;
}

const validId = (id: string) => Types.ObjectId.isValid(id) && String(new Types.ObjectId(id)) === id;

export async function createUser(input: NewUser): Promise<PublicUser> {
  const doc = await UserModel.create({
    username: input.username,
    email: input.email,
    passwordHash: input.passwordHash,
    displayName: input.displayName,
  });
  return toPublicUser(doc); // the serializer drops passwordHash
}

/** Which of the two unique fields are already taken (username is case-insensitive). */
export async function findTaken(username: string, email: string): Promise<{ username: boolean; email: boolean }> {
  const lower = username.toLowerCase();
  const rows = await UserModel.find({ $or: [{ usernameLower: lower }, { email }] })
    .select("usernameLower email")
    .lean();
  return { username: rows.some((r) => r.usernameLower === lower), email: rows.some((r) => r.email === email) };
}

/** Login only: the one query that asks for passwordHash. Callers must strip it before responding. */
export async function findCredentialsByEmail(email: string) {
  const row = await UserModel.findOne({ email }).select("+passwordHash").lean();
  if (!row) return null;
  return { ...toPublicUser(row), password_hash: row.passwordHash as string };
}

/** MongoDB duplicate-key error (unique index hit). */
export const isUniqueViolation = (err: unknown) => (err as { code?: number } | null)?.code === 11000;

export async function findPublicById(id: string): Promise<PublicUser | null> {
  if (!validId(id)) return null;
  const row = await UserModel.findById(id).lean();
  return row ? toPublicUser(row) : null;
}

export async function displayNames(ids: string[]): Promise<string[]> {
  if (!ids.length) return [];
  const rows = await UserModel.find({ _id: { $in: ids } }).sort({ usernameLower: 1 }).select("displayName username").lean();
  return rows.map((r) => (r.displayName ?? r.username) as string);
}

export async function searchUsers(q: string, excludeId: string): Promise<UserLite[]> {
  const escaped = q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // escape regex characters
  const rows = await UserModel.find({
    _id: { $ne: excludeId },
    $or: [{ usernameLower: { $regex: escaped.toLowerCase() } }, { displayName: { $regex: escaped, $options: "i" } }],
  })
    .sort({ usernameLower: 1 })
    .limit(10)
    .lean();
  return rows.map(toUserLite);
}

export async function updateProfile(id: string, patch: { displayName?: string; bio?: string; avatarUrl?: string }) {
  const row = await UserModel.findByIdAndUpdate(id, { $set: patch }, { new: true, runValidators: true }).lean();
  return row ? toPublicUser(row) : null;
}

export async function getStats(userId: string) {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const [rooms, sentToday] = await Promise.all([
    RoomModel.countDocuments({ "members.user": userId }),
    MessageModel.countDocuments({ sender: userId, type: { $ne: "system" }, createdAt: { $gte: startOfDay } }),
  ]);
  return { rooms, sent_today: sentToday };
}

export const setStatus = (id: string, status: "online" | "away" | "offline") =>
  UserModel.updateOne({ _id: id }, { $set: { status, ...(status === "offline" ? { lastSeenAt: new Date() } : {}) } });
