import type { Server as HttpServer } from "http";
import { Server } from "socket.io";
import { config } from "./config.js";
import { verifyToken } from "./middleware/auth.js";
import { createMessage } from "./models/message.js";
import { markRead } from "./models/room.js";
import { RoomModel } from "./models/schemas.js";
import { setStatus } from "./models/user.js";
import { setIo } from "./services/realtime.js";
import { isObjectId } from "./validation/rooms.js";

export function attachSocket(httpServer: HttpServer) {
  const io = new Server(httpServer, { cors: { origin: config.clientOrigin } });
  setIo(io);

  io.use((socket, next) => {
    const userId = verifyToken(String(socket.handshake.auth?.token ?? ""));
    if (!userId) return next(new Error("Unauthorized"));
    socket.data.userId = userId;
    next();
  });

  io.on("connection", async (socket) => {
    const userId: string = socket.data.userId;

    // Personal room lets the REST layer reach every tab this user has open
    socket.join(`user:${userId}`);

    // Join a socket.io room for every chat room the user belongs to
    const rooms = await RoomModel.find({ "members.user": userId }).select("_id").lean();
    rooms.forEach((r) => socket.join(String(r._id)));
    await setStatus(userId, "online");

    socket.on("message:send", async ({ roomId, content, replyToId }) => {
      if (!isObjectId(roomId) || typeof content !== "string") return;
      const text = content.trim();
      if (!text || text.length > 4000 || !socket.rooms.has(roomId)) return;
      const msg = await createMessage({
        room: roomId,
        sender: userId,
        content: text,
        replyTo: isObjectId(replyToId) ? replyToId : null,
      });
      io.to(roomId).emit("message:new", msg);
    });

    socket.on("room:read", async ({ roomId, messageId }) => {
      if (!isObjectId(roomId) || !isObjectId(messageId)) return;
      await markRead(roomId, userId, messageId);
    });

    socket.on("typing", ({ roomId, isTyping }) => {
      if (!isObjectId(roomId) || !socket.rooms.has(roomId)) return;
      socket.to(roomId).emit("typing", { roomId, userId, isTyping: Boolean(isTyping) });
    });

    socket.on("disconnect", async () => {
      await setStatus(userId, "offline");
    });
  });

  return io;
}
