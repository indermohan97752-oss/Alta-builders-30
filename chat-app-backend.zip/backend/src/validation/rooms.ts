import { z } from "zod";

/** MongoDB ObjectId as a 24-character hex string. */
export const objectId = z.string().regex(/^[a-f0-9]{24}$/i, "Invalid id");
export const isObjectId = (v: unknown): v is string => typeof v === "string" && /^[a-f0-9]{24}$/i.test(v);

const name = z
  .string()
  .trim()
  .min(1, "Room name is required")
  .max(80, "Room name must be 80 characters or fewer");

const description = z
  .string()
  .trim()
  .max(255, "Description must be 255 characters or fewer")
  .transform((v) => v || null);

const uniqueIds = (max: number, min = 0) =>
  z.array(objectId).min(min).max(max).transform((ids) => [...new Set(ids)]);

export const createRoomSchema = z.object({
  name,
  description: description.optional(),
  memberIds: uniqueIds(99).default([]),
});

export const updateRoomSchema = z
  .object({ name: name.optional(), description: description.optional() })
  .refine((v) => v.name !== undefined || v.description !== undefined, "Nothing to update");

export const addMembersSchema = z.object({ userIds: uniqueIds(50, 1) });
export const roleSchema = z.object({ role: z.enum(["admin", "member"]) });
export const mutedSchema = z.object({ isMuted: z.boolean() });
export const dmSchema = z.object({ userId: objectId });
