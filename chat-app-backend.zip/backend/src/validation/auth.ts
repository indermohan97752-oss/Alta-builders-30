import { z } from "zod";

const MAX_PASSWORD_BYTES = 72;

const email = z.string().trim().toLowerCase().email("Enter a valid email address").max(255);

export const signupSchema = z.object({
  username: z
    .string()
    .trim()
    .regex(/^[A-Za-z0-9_]{3,30}$/, "Username must be 3-30 characters: letters, numbers or underscores"),
  email,
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .refine((p) => Buffer.byteLength(p, "utf8") <= MAX_PASSWORD_BYTES, "Password is too long (72 bytes max)")
    .refine((p) => /[A-Za-z]/.test(p) && /\d/.test(p), "Password must include at least one letter and one number"),
  displayName: z
    .string()
    .trim()
    .max(60, "Display name must be 60 characters or fewer")
    .optional()
    .transform((v) => v || undefined),
});

export const loginSchema = z.object({
  email,
  password: z.string().min(1, "Password is required").max(128),
});

export type SignupInput = z.infer<typeof signupSchema>;

export const profileSchema = z
  .object({
    displayName: z.string().trim().min(1, "Display name can't be empty").max(60).optional(),
    bio: z.string().trim().max(200, "Bio must be 200 characters or fewer").optional(),
    avatarUrl: z.string().trim().url("Avatar must be a valid URL").max(500).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, "Nothing to update");
