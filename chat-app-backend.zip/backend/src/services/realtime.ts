import type { Server } from "socket.io";
import { createMessage } from "../models/message.js";

let io: Server | undefined;
export const setIo = (server: Server) => { io = server; };

/** Put live sockets into the room and tell the clients. */
export function memberJoined(roomId: string, userIds: string[]) {
  for (const id of userIds) {
    io?.in(`user:${id}`).socketsJoin(roomId);
    io?.to(`user:${id}`).emit("room:added", { roomId });
  }
  io?.to(roomId).emit("room:updated", { roomId });
}

export function memberLeft(roomId: string, userIds: string[]) {
  for (const id of userIds) {
    io?.to(`user:${id}`).emit("room:removed", { roomId });
    io?.in(`user:${id}`).socketsLeave(roomId);
  }
  io?.to(roomId).emit("room:updated", { roomId });
}

export function roomDeleted(roomId: string) {
  io?.to(roomId).emit("room:removed", { roomId });
  io?.in(roomId).socketsLeave(roomId);
}

export const roomChanged = (roomId: string) => io?.to(roomId).emit("room:updated", { roomId });

/** "Ana added Rahul" style notices, stored as type='system' messages. */
export async function postSystemMessage(roomId: string, actorId: string, content: string) {
  const msg = await createMessage({ room: roomId, sender: actorId, content, type: "system" });
  io?.to(roomId).emit("message:new", msg);
}
