/**
 * Integration tests: real Express app + real MongoDB, over HTTP.
 *
 * Run with MongoDB up (npm run db:up):   npm run test:integration -w backend
 * Uses a separate database (default chat_test), which is DROPPED and rebuilt on every run.
 */
import assert from "node:assert/strict";
import http from "node:http";
import { after, before, describe, it } from "node:test";
import jwt from "jsonwebtoken";
import mongoose from "mongoose";

const TEST_URI = process.env.TEST_MONGODB_URI ?? "mongodb://localhost:27017/chat_test";
const dbName = new URL(TEST_URI).pathname.slice(1);
if (!/^[a-z0-9_]+_test$/.test(dbName)) {
  throw new Error(`Refusing to run: test database "${dbName}" must end in "_test" (it is dropped on every run)`);
}

// Must be set before the app's modules are imported (config reads env at import time)
process.env.MONGODB_URI = TEST_URI;
process.env.JWT_SECRET = "integration-test-secret";
process.env.BCRYPT_ROUNDS = "4";
process.env.NODE_ENV = "test";

type Models = typeof import("../../models/schemas.js");
let m: Models;
let base = "";
let server: http.Server;
let closeDb: () => Promise<void>;
const users: Record<string, { id: string; token: string }> = {};

async function api(method: string, path: string, opts: { token?: string; body?: unknown } = {}) {
  const hasBody = opts.body !== undefined;
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(hasBody ? { "Content-Type": "application/json" } : {}),
      ...(opts.token ? { Authorization: `Bearer ${opts.token}` } : {}),
    },
    body: hasBody ? JSON.stringify(opts.body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null };
}

async function signup(username: string) {
  const r = await api("POST", "/api/auth/signup", {
    body: { username, email: `${username}@example.com`, password: "Password1234" },
  });
  assert.equal(r.status, 201, `signup ${username}: ${JSON.stringify(r.body)}`);
  assert.equal("password_hash" in r.body.user, false, "signup response must not include password_hash");
  assert.equal("passwordHash" in r.body.user, false, "signup response must not include passwordHash");
  users[username] = { id: r.body.user.id, token: r.body.token };
}

before(async () => {
  const db = await import("../../db.js");
  closeDb = db.closeDb;
  await db.connectDb();
  await mongoose.connection.dropDatabase();

  const { initDatabase } = await import("../../db/init.js");
  await initDatabase();
  m = await import("../../models/schemas.js");

  const { createApp } = await import("../../app.js");
  server = http.createServer(createApp());
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;

  for (const name of ["alice", "bob", "carol"]) await signup(name);
});

after(async () => {
  await new Promise((resolve) => server?.close(resolve));
  await closeDb?.();
});

describe("setup", () => {
  it("health check reports the database is up", async () => {
    const r = await api("GET", "/health");
    assert.equal(r.status, 200);
    assert.equal(r.body.checks.database, "up");
  });

  it("stores only bcrypt hashes; queries never return the hash by default", async () => {
    const plain = await m.UserModel.findOne({ username: "alice" }).lean();
    assert.equal("passwordHash" in (plain as object), false, "passwordHash is select:false");
    const withHash = await m.UserModel.findOne({ username: "alice" }).select("+passwordHash").lean();
    assert.match(withHash!.passwordHash, /^\$2[aby]\$\d{2}\$/);
  });

  it("MongoDB itself rejects a plaintext password, bypassing the app layer", async () => {
    await assert.rejects(
      mongoose.connection.collection("users").insertOne({
        username: "raw", usernameLower: "raw", email: "raw@example.com", passwordHash: "Password1234",
      }),
      (err: { code?: number }) => err.code === 121, // DocumentValidationFailure
    );
  });

  it("usernames are unique ignoring case (409)", async () => {
    const r = await api("POST", "/api/auth/signup", {
      body: { username: "ALICE", email: "other@example.com", password: "Password1234" },
    });
    assert.equal(r.status, 409);
  });
});

describe("authentication on every room endpoint", () => {
  let probeRoomId = "";
  before(async () => {
    const r = await api("POST", "/api/rooms", { token: users.alice.token, body: { name: "Auth probe" } });
    probeRoomId = r.body.id;
  });

  const endpoints = (id: string): [string, string, unknown?][] => [
    ["POST", "/api/rooms", { name: "x" }],
    ["GET", "/api/rooms"],
    ["GET", `/api/rooms/${id}`],
    ["PATCH", `/api/rooms/${id}`, { name: "x" }],
    ["DELETE", `/api/rooms/${id}`],
  ];

  it("rejects requests with no token (401)", async () => {
    for (const [method, path, body] of endpoints(probeRoomId)) {
      const r = await api(method, path, { body });
      assert.equal(r.status, 401, `${method} ${path}`);
    }
  });

  it("rejects a malformed token (401)", async () => {
    for (const [method, path, body] of endpoints(probeRoomId)) {
      const r = await api(method, path, { token: "not-a-jwt", body });
      assert.equal(r.status, 401, `${method} ${path}`);
    }
  });

  it("rejects a token signed with the wrong secret (401)", async () => {
    const forged = jwt.sign({ sub: users.alice.id }, "some-other-secret");
    for (const [method, path, body] of endpoints(probeRoomId)) {
      const r = await api(method, path, { token: forged, body });
      assert.equal(r.status, 401, `${method} ${path}`);
    }
  });

  it("rejects an expired token (401)", async () => {
    const expired = jwt.sign({ sub: users.alice.id }, process.env.JWT_SECRET!, { expiresIn: -10 });
    const r = await api("GET", "/api/rooms", { token: expired });
    assert.equal(r.status, 401);
  });

  it("the room was not touched by any of the rejected requests", async () => {
    const r = await api("GET", `/api/rooms/${probeRoomId}`, { token: users.alice.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.name, "Auth probe");
  });
});

describe("rooms CRUD (authenticated)", () => {
  let roomId = "";

  // ---- CREATE ----
  it("POST /api/rooms creates a group; the creator becomes owner", async () => {
    const r = await api("POST", "/api/rooms", {
      token: users.alice.token,
      body: {
        name: "  Design team  ",
        memberIds: [users.bob.id, users.bob.id, "111111111111111111111111"], // duplicate + id that matches no user
      },
    });
    assert.equal(r.status, 201);
    assert.equal(r.body.name, "Design team"); // trimmed
    assert.equal(r.body.type, "group");
    assert.equal(r.body.description, null);
    assert.equal(r.body.created_by, users.alice.id);
    roomId = r.body.id;

    const details = await api("GET", `/api/rooms/${roomId}`, { token: users.alice.token });
    assert.equal(details.body.my_role, "owner");
    const roles = Object.fromEntries(details.body.members.map((x: any) => [x.username, x.role]));
    assert.deepEqual(roles, { alice: "owner", bob: "member" }); // duplicate and unknown id ignored
  });

  it("POST /api/rooms rejects a blank name with a field error (400)", async () => {
    const r = await api("POST", "/api/rooms", { token: users.alice.token, body: { name: "   " } });
    assert.equal(r.status, 400);
    assert.ok(r.body.fields.name.length > 0);
  });

  it("POST /api/rooms rejects invalid JSON (400, not 500)", async () => {
    const res = await fetch(`${base}/api/rooms`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${users.alice.token}` },
      body: "{not json",
    });
    assert.equal(res.status, 400);
  });

  // ---- READ ----
  it("GET /api/rooms lists rooms for members only", async () => {
    const names = async (u: { token: string }) =>
      (await api("GET", "/api/rooms", { token: u.token })).body.map((r: any) => r.name);
    assert.ok((await names(users.alice)).includes("Design team"));
    assert.ok((await names(users.bob)).includes("Design team"));
    assert.ok(!(await names(users.carol)).includes("Design team"));
  });

  it("GET /api/rooms/:id returns details and members to a member", async () => {
    const r = await api("GET", `/api/rooms/${roomId}`, { token: users.bob.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.name, "Design team");
    assert.equal(r.body.my_role, "member");
    assert.equal(r.body.members.length, 2);
    assert.equal(JSON.stringify(r.body).toLowerCase().includes("password"), false);
  });

  it("GET /api/rooms/:id is 404 for a non-member and for a malformed id", async () => {
    assert.equal((await api("GET", `/api/rooms/${roomId}`, { token: users.carol.token })).status, 404);
    assert.equal((await api("GET", "/api/rooms/not-an-id", { token: users.alice.token })).status, 404);
  });

  // ---- UPDATE ----
  it("PATCH /api/rooms/:id lets the owner rename and persists it", async () => {
    const r = await api("PATCH", `/api/rooms/${roomId}`, {
      token: users.alice.token,
      body: { name: "Design crew", description: "Mockups and reviews" },
    });
    assert.equal(r.status, 200);
    assert.equal(r.body.name, "Design crew");

    const again = await api("GET", `/api/rooms/${roomId}`, { token: users.bob.token });
    assert.equal(again.body.name, "Design crew");
    assert.equal(again.body.description, "Mockups and reviews");

    const sys = await m.MessageModel.find({ room: roomId, type: "system" }).lean();
    assert.ok(sys.some((x) => /renamed the room/.test(x.content ?? "")), "a system message records the rename");
  });

  it("PATCH with an empty description clears it", async () => {
    const r = await api("PATCH", `/api/rooms/${roomId}`, { token: users.alice.token, body: { description: "" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.description, null);
  });

  it("PATCH is forbidden for a plain member (403) and hidden from non-members (404)", async () => {
    assert.equal((await api("PATCH", `/api/rooms/${roomId}`, { token: users.bob.token, body: { name: "Hacked" } })).status, 403);
    assert.equal((await api("PATCH", `/api/rooms/${roomId}`, { token: users.carol.token, body: { name: "Hacked" } })).status, 404);
    const check = await api("GET", `/api/rooms/${roomId}`, { token: users.alice.token });
    assert.equal(check.body.name, "Design crew");
  });

  it("PATCH rejects empty and invalid bodies (400)", async () => {
    assert.equal((await api("PATCH", `/api/rooms/${roomId}`, { token: users.alice.token, body: {} })).status, 400);
    assert.equal((await api("PATCH", `/api/rooms/${roomId}`, { token: users.alice.token, body: { name: "" } })).status, 400);
  });

  // ---- DELETE ----
  it("DELETE is forbidden for a member (403) and hidden from non-members (404)", async () => {
    assert.equal((await api("DELETE", `/api/rooms/${roomId}`, { token: users.bob.token })).status, 403);
    assert.equal((await api("DELETE", `/api/rooms/${roomId}`, { token: users.carol.token })).status, 404);
    assert.equal((await api("GET", `/api/rooms/${roomId}`, { token: users.alice.token })).status, 200);
  });

  it("DELETE /api/rooms/:id lets the owner delete a room that has messages and replies", async () => {
    const m1 = await m.MessageModel.create({ room: roomId, sender: users.alice.id, content: "hello" });
    await m.MessageModel.create({ room: roomId, sender: users.bob.id, content: "reply", replyTo: m1._id });
    await m.RoomModel.updateOne(
      { _id: roomId, "members.user": users.bob.id },
      { $set: { "members.$.lastReadMessageId": m1._id } },
    );

    const r = await api("DELETE", `/api/rooms/${roomId}`, { token: users.alice.token });
    assert.equal(r.status, 204);

    assert.equal(await m.MessageModel.countDocuments({ room: roomId }), 0, "messages are removed with the room");
    assert.equal(await m.RoomModel.countDocuments({ _id: roomId }), 0);
  });

  it("the deleted room is gone for everyone", async () => {
    assert.equal((await api("GET", `/api/rooms/${roomId}`, { token: users.alice.token })).status, 404);
    assert.equal((await api("DELETE", `/api/rooms/${roomId}`, { token: users.alice.token })).status, 404);
    const list = await api("GET", "/api/rooms", { token: users.bob.token });
    assert.ok(!list.body.some((room: any) => room.id === roomId));
  });
});
