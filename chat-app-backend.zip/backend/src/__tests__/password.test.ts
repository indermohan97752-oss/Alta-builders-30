import assert from "node:assert/strict";
import { describe, it } from "node:test";

process.env.DATABASE_URL ??= "postgres://test:test@localhost:5432/test";
process.env.JWT_SECRET ??= "test-secret-123";
process.env.BCRYPT_ROUNDS = "4"; // fast for tests

const { hashPassword, verifyPassword } = await import("../services/password.js");

describe("password service", () => {
  it("never returns the plaintext and produces a bcrypt hash", async () => {
    const hash = await hashPassword("correct horse 1");
    assert.notEqual(hash, "correct horse 1");
    assert.ok(!hash.includes("correct horse"));
    assert.match(hash, /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/);
  });

  it("verifies the right password and rejects the wrong one", async () => {
    const hash = await hashPassword("correct horse 1");
    assert.equal(await verifyPassword("correct horse 1", hash), true);
    assert.equal(await verifyPassword("wrong horse 1", hash), false);
  });

  it("salts: the same password hashes differently each time", async () => {
    assert.notEqual(await hashPassword("same-pass-1"), await hashPassword("same-pass-1"));
  });
});
