import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  addMembersSchema, createRoomSchema, dmSchema, mutedSchema, roleSchema, updateRoomSchema,
} from "../validation/rooms.js";

const id = "507f1f77bcf86cd799439011"; // MongoDB ObjectId
const id2 = "507f191e810c19729de860ea";

describe("room validation", () => {
  it("createRoom trims the name, dedupes members and defaults memberIds", () => {
    const r = createRoomSchema.parse({ name: "  Design team ", memberIds: [id, id, id2] });
    assert.equal(r.name, "Design team");
    assert.deepEqual(r.memberIds, [id, id2]);
    assert.deepEqual(createRoomSchema.parse({ name: "x" }).memberIds, []);
  });

  it("createRoom rejects blank or oversized names and non-ObjectId members", () => {
    assert.equal(createRoomSchema.safeParse({ name: "   " }).success, false);
    assert.equal(createRoomSchema.safeParse({ name: "x".repeat(81) }).success, false);
    assert.equal(createRoomSchema.safeParse({ name: "ok", memberIds: ["nope"] }).success, false);
    assert.equal(createRoomSchema.safeParse({ name: "ok", description: "d".repeat(256) }).success, false);
  });

  it("empty description becomes null (clears it)", () => {
    assert.equal(createRoomSchema.parse({ name: "ok", description: "  " }).description, null);
    assert.equal(updateRoomSchema.parse({ description: "" }).description, null);
  });

  it("updateRoom requires at least one field", () => {
    assert.equal(updateRoomSchema.safeParse({}).success, false);
    assert.equal(updateRoomSchema.safeParse({ name: "New" }).success, true);
  });

  it("addMembers needs 1-50 ids", () => {
    assert.equal(addMembersSchema.safeParse({ userIds: [] }).success, false);
    assert.equal(addMembersSchema.safeParse({ userIds: [id] }).success, true);
    assert.equal(addMembersSchema.safeParse({ userIds: Array.from({ length: 51 }, (_, i) => String(i).padStart(24, "0")) }).success, false);
  });

  it("role can be admin or member, never owner", () => {
    assert.equal(roleSchema.safeParse({ role: "admin" }).success, true);
    assert.equal(roleSchema.safeParse({ role: "owner" }).success, false);
  });

  it("muted and dm bodies", () => {
    assert.equal(mutedSchema.safeParse({ isMuted: "yes" }).success, false);
    assert.equal(dmSchema.safeParse({ userId: id }).success, true);
    assert.equal(dmSchema.safeParse({ userId: "x" }).success, false);
    assert.equal(dmSchema.safeParse({ userId: "3f2b8c1e-5a6d-4e7f-9a0b-1c2d3e4f5a6b" }).success, false); // a UUID is not an ObjectId
  });
});
