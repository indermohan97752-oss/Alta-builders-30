import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { signupSchema } from "../validation/auth.js";

const valid = { username: "sid_k", email: "Sid@Example.com ", password: "hunter2hunter2" };

describe("signupSchema", () => {
  it("accepts valid input and normalizes the email", () => {
    const r = signupSchema.parse(valid);
    assert.equal(r.email, "sid@example.com");
    assert.equal(r.displayName, undefined);
  });

  it("rejects bad usernames", () => {
    for (const username of ["ab", "has space", "emoji😀", "x".repeat(31)]) {
      assert.equal(signupSchema.safeParse({ ...valid, username }).success, false, username);
    }
  });

  it("rejects bad emails", () => {
    assert.equal(signupSchema.safeParse({ ...valid, email: "nope" }).success, false);
  });

  it("rejects weak passwords", () => {
    for (const password of ["short1", "onlyletters", "12345678"]) {
      assert.equal(signupSchema.safeParse({ ...valid, password }).success, false, password);
    }
  });

  it("rejects passwords over bcrypt's 72-byte limit (counted in bytes, not characters)", () => {
    assert.equal(signupSchema.safeParse({ ...valid, password: "a1".repeat(36) }).success, true); // 72 bytes
    assert.equal(signupSchema.safeParse({ ...valid, password: "a1".repeat(36) + "x" }).success, false); // 73
    assert.equal(signupSchema.safeParse({ ...valid, password: "a1" + "😀".repeat(18) }).success, false); // 74 bytes
  });

  it("ignores unexpected fields so clients cannot set columns like role or id", () => {
    const r = signupSchema.parse({ ...valid, id: "x", role: "admin", password_hash: "x" });
    assert.deepEqual(Object.keys(r).sort(), ["displayName", "email", "password", "username"]);
  });
});
