import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  canAddMembers, canChangeRole, canDeleteRoom, canEditRoom, canRemoveMember,
} from "../services/permissions.js";

describe("room permissions", () => {
  it("owner and admin can edit the room and add members; members cannot", () => {
    for (const fn of [canEditRoom, canAddMembers]) {
      assert.equal(fn("owner"), true);
      assert.equal(fn("admin"), true);
      assert.equal(fn("member"), false);
    }
  });

  it("only the owner can delete the room", () => {
    assert.equal(canDeleteRoom("owner"), true);
    assert.equal(canDeleteRoom("admin"), false);
    assert.equal(canDeleteRoom("member"), false);
  });

  it("removal needs a strictly higher role", () => {
    assert.equal(canRemoveMember("owner", "admin"), true);
    assert.equal(canRemoveMember("owner", "member"), true);
    assert.equal(canRemoveMember("admin", "member"), true);
    assert.equal(canRemoveMember("admin", "admin"), false);
    assert.equal(canRemoveMember("admin", "owner"), false);
    assert.equal(canRemoveMember("member", "member"), false);
    assert.equal(canRemoveMember("member", "admin"), false);
  });

  it("only the owner changes roles, only between admin and member", () => {
    assert.equal(canChangeRole("owner", "member", "admin"), true);
    assert.equal(canChangeRole("owner", "admin", "member"), true);
    assert.equal(canChangeRole("owner", "owner", "member"), false);
    assert.equal(canChangeRole("admin", "member", "admin"), false);
    assert.equal(canChangeRole("member", "member", "admin"), false);
  });
});
