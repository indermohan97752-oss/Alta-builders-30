import mongoose from "mongoose";
import { pathToFileURL } from "url";
import { closeDb, connectDb } from "../db.js";
import { MessageModel, RoomModel, UserModel } from "../models/schemas.js";

// Same pattern the schema uses, enforced by MongoDB itself so nothing can bypass it
const BCRYPT_PATTERN = "^\\$2[aby]\\$[0-9]{2}\\$[./A-Za-z0-9]{53}$";

const validators: Record<string, object> = {
  users: {
    $jsonSchema: {
      bsonType: "object",
      required: ["username", "usernameLower", "email", "passwordHash"],
      properties: {
        passwordHash: { bsonType: "string", pattern: BCRYPT_PATTERN }, // a plaintext password cannot be stored
        email: { bsonType: "string", pattern: "^[^A-Z]*$" }, // stored lowercased
      },
    },
  },
  // groups need a name; direct rooms need their dmKey
  rooms: { $or: [{ type: "direct", dmKey: { $type: "string" } }, { type: "group", name: { $regex: "\\S" } }] },
};

/** Idempotent: creates collections, applies validators, builds indexes. Safe to run on every start. */
export async function initDatabase(): Promise<void> {
  const models = [UserModel, RoomModel, MessageModel];
  await Promise.all(models.map((m) => m.init())); // creates collections and indexes

  const db = mongoose.connection.db!;
  for (const [name, validator] of Object.entries(validators)) {
    await db.command({ collMod: name, validator, validationLevel: "strict", validationAction: "error" });
  }
  await Promise.all(models.map((m) => m.syncIndexes())); // also drops indexes no longer in the schema
  console.log("Database ready: collections, validators and indexes are in place");
}

// Run as a script: npm run db:init
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  connectDb()
    .then(initDatabase)
    .catch((err) => { console.error("Database init failed:", err.message); process.exitCode = 1; })
    .finally(closeDb);
}
