import { Router, type Response } from "express";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";
import { loadMembership, requireGroup, type RoomRequest } from "../middleware/rooms.js";
import {
  addMembers, createGroup, deleteRoom, getMembership, getOrCreateDm, getRoomDetails,
  leaveGroup, listRoomsForUser, removeMember, setMuted, setRole, updateRoom,
} from "../models/room.js";
import { listMessages } from "../models/message.js";
import { displayNames, findPublicById } from "../models/user.js";
import {
  canAddMembers, canChangeRole, canDeleteRoom, canEditRoom, canRemoveMember,
} from "../services/permissions.js";
import { memberJoined, memberLeft, postSystemMessage, roomChanged, roomDeleted } from "../services/realtime.js";
import { sendValidationError } from "../validation/respond.js";
import {
  addMembersSchema, createRoomSchema, dmSchema, mutedSchema, objectId, roleSchema, updateRoomSchema,
} from "../validation/rooms.js";

export const roomsRouter = Router();
roomsRouter.use(requireAuth);

const forbidden = (res: Response, msg = "You don't have permission to do that") =>
  res.status(403).json({ error: msg });

const actorName = async (userId: string) => {
  const u = await findPublicById(userId);
  return u?.display_name ?? u?.username ?? "Someone";
};

// ---- list / create -------------------------------------------------------

roomsRouter.get("/", async (req: AuthedRequest, res) => {
  res.json(await listRoomsForUser(req.userId!));
});

roomsRouter.post("/", async (req: AuthedRequest, res) => {
  const parsed = createRoomSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);
  const { room, addedIds } = await createGroup(req.userId!, parsed.data);
  memberJoined(room.id, [req.userId!, ...addedIds]);
  res.status(201).json(room);
});

roomsRouter.post("/dm", async (req: AuthedRequest, res) => {
  const parsed = dmSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);
  const otherId = parsed.data.userId;
  if (otherId === req.userId) return res.status(400).json({ error: "You can't start a chat with yourself" });
  if (!(await findPublicById(otherId))) return res.status(404).json({ error: "User not found" });

  const { room, created } = await getOrCreateDm(req.userId!, otherId);
  if (created) memberJoined(room.id, [req.userId!, otherId]);
  res.status(created ? 201 : 200).json(room);
});

// ---- one room ------------------------------------------------------------

roomsRouter.get("/:roomId", loadMembership, async (req: RoomRequest, res) => {
  const details = await getRoomDetails(req.params.roomId, req.userId!);
  if (!details) return res.status(404).json({ error: "Room not found" });
  res.json({ ...details, my_user_id: req.userId, my_role: req.membership!.role, is_muted: req.membership!.is_muted });
});

roomsRouter.patch("/:roomId", loadMembership, requireGroup, async (req: RoomRequest, res) => {
  if (!canEditRoom(req.membership!.role)) return forbidden(res);
  const parsed = updateRoomSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);

  const room = await updateRoom(req.params.roomId, parsed.data);
  if (parsed.data.name !== undefined) {
    await postSystemMessage(room.id, req.userId!, `${await actorName(req.userId!)} renamed the room to "${room.name}"`);
  }
  roomChanged(room.id);
  res.json(room);
});

roomsRouter.delete("/:roomId", loadMembership, requireGroup, async (req: RoomRequest, res) => {
  if (!canDeleteRoom(req.membership!.role)) return forbidden(res, "Only the owner can delete a room");
  await deleteRoom(req.params.roomId);
  roomDeleted(req.params.roomId);
  res.status(204).end();
});

// ---- members -------------------------------------------------------------

roomsRouter.post("/:roomId/members", loadMembership, requireGroup, async (req: RoomRequest, res) => {
  if (!canAddMembers(req.membership!.role)) return forbidden(res);
  const parsed = addMembersSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);

  const added = await addMembers(req.params.roomId, parsed.data.userIds);
  if (added.length) {
    memberJoined(req.params.roomId, added);
    const names = await displayNames(added);
    await postSystemMessage(req.params.roomId, req.userId!, `${await actorName(req.userId!)} added ${names.join(", ")}`);
  }
  res.status(added.length ? 201 : 200).json({ addedIds: added });
});

roomsRouter.patch("/:roomId/members/:userId", loadMembership, requireGroup, async (req: RoomRequest, res) => {
  const { roomId, userId } = req.params;
  const parsed = roleSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);
  if (!objectId.safeParse(userId).success) return res.status(404).json({ error: "Member not found" });

  const target = await getMembership(roomId, userId);
  if (!target) return res.status(404).json({ error: "Member not found" });
  if (!canChangeRole(req.membership!.role, target.role, parsed.data.role)) {
    return forbidden(res, "Only the owner can change roles, and the owner's role can't be changed");
  }
  await setRole(roomId, userId, parsed.data.role);
  roomChanged(roomId);
  res.json({ userId, role: parsed.data.role });
});

// Removing yourself is "leave"; removing someone else needs a higher role
roomsRouter.delete("/:roomId/members/:userId", loadMembership, requireGroup, async (req: RoomRequest, res) => {
  const { roomId, userId } = req.params;
  if (!objectId.safeParse(userId).success) return res.status(404).json({ error: "Member not found" });

  if (userId === req.userId) {
    const result = await leaveGroup(roomId, userId);
    memberLeft(roomId, [userId]);
    if (result.left && !result.roomDeleted) {
      await postSystemMessage(roomId, userId, `${await actorName(userId)} left`);
    }
    return res.status(204).end();
  }

  const target = await getMembership(roomId, userId);
  if (!target) return res.status(404).json({ error: "Member not found" });
  if (!canRemoveMember(req.membership!.role, target.role)) return forbidden(res);

  await removeMember(roomId, userId);
  memberLeft(roomId, [userId]);
  const [targetName] = await displayNames([userId]);
  await postSystemMessage(roomId, req.userId!, `${await actorName(req.userId!)} removed ${targetName}`);
  res.status(204).end();
});

// ---- per-user room settings ----------------------------------------------

roomsRouter.patch("/:roomId/me", loadMembership, async (req: RoomRequest, res) => {
  const parsed = mutedSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);
  await setMuted(req.params.roomId, req.userId!, parsed.data.isMuted);
  res.json({ isMuted: parsed.data.isMuted });
});

// ---- messages (cursor pagination by message id) --------------------------

roomsRouter.get("/:roomId/messages", loadMembership, async (req: RoomRequest, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit ?? 30) || 30, 1), 100);
  const before = typeof req.query.before === "string" && /^[a-f0-9]{24}$/i.test(req.query.before) ? req.query.before : null;

  res.json(await listMessages(req.params.roomId, before, limit));
});
