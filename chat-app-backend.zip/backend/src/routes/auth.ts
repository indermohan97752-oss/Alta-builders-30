import { Router } from "express";
import { signToken } from "../middleware/auth.js";
import { createUser, findCredentialsByEmail, findTaken, isUniqueViolation } from "../models/user.js";
import { dummyHash, hashPassword, verifyPassword } from "../services/password.js";
import { loginSchema, signupSchema } from "../validation/auth.js";

export const authRouter = Router();

const conflict = (fields: { username?: boolean; email?: boolean }) => ({
  error: "Already in use",
  fields: {
    ...(fields.username && { username: ["That username is taken"] }),
    ...(fields.email && { email: ["An account with that email already exists"] }),
  },
});

authRouter.post("/signup", async (req, res) => {
  const parsed = signupSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Validation failed", fields: parsed.error.flatten().fieldErrors });
  }
  const { username, email, password, displayName } = parsed.data;

  const taken = await findTaken(username, email);
  if (taken.username || taken.email) return res.status(409).json(conflict(taken));

  // Only the hash ever leaves this scope; `password` is never logged or stored
  const passwordHash = await hashPassword(password);

  try {
    const user = await createUser({ username, email, passwordHash, displayName: displayName ?? username });
    return res.status(201).json({ token: signToken(user.id), user });
  } catch (err) {
    // Two signups racing past the check above are still caught by the DB unique indexes
    if (isUniqueViolation(err)) return res.status(409).json(conflict({ username: true, email: true }));
    throw err;
  }
});

authRouter.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Validation failed", fields: parsed.error.flatten().fieldErrors });
  }
  const { email, password } = parsed.data;

  const found = await findCredentialsByEmail(email);
  const ok = await verifyPassword(password, found?.password_hash ?? (await dummyHash()));
  if (!found || !ok) return res.status(401).json({ error: "Invalid email or password" });

  const { password_hash: _omit, ...user } = found;
  res.json({ token: signToken(user.id), user });
});
