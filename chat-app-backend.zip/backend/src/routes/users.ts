import { Router } from "express";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";
import { findPublicById, getStats, searchUsers, updateProfile } from "../models/user.js";
import { profileSchema } from "../validation/auth.js";
import { sendValidationError } from "../validation/respond.js";

export const usersRouter = Router();
usersRouter.use(requireAuth);

// Search for people to message or add to a room
usersRouter.get("/", async (req: AuthedRequest, res) => {
  const q = String(req.query.q ?? "").trim();
  if (q.length < 2) return res.json([]);
  res.json(await searchUsers(q.slice(0, 50), req.userId!));
});

usersRouter.get("/me", async (req: AuthedRequest, res) => {
  const user = await findPublicById(req.userId!);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ ...user, stats: await getStats(req.userId!) });
});

usersRouter.patch("/me", async (req: AuthedRequest, res) => {
  const parsed = profileSchema.safeParse(req.body);
  if (!parsed.success) return sendValidationError(res, parsed.error);
  const user = await updateProfile(req.userId!, parsed.data);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json(user);
});
