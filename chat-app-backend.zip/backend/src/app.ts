import "express-async-errors";
import cors from "cors";
import express from "express";
import { config } from "./config.js";
import { authRouter } from "./routes/auth.js";
import { healthRouter } from "./routes/health.js";
import { roomsRouter } from "./routes/rooms.js";
import { usersRouter } from "./routes/users.js";

export function createApp() {
  const app = express();
  app.use(cors({ origin: config.clientOrigin }));
  app.use(express.json());

  app.use("/health", healthRouter);
  app.use("/api/health", healthRouter); // reachable through the Vite dev proxy too
  app.use("/api/auth", authRouter);
  app.use("/api/users", usersRouter);
  app.use("/api/rooms", roomsRouter);

  app.use((err: Error & { status?: number }, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    // Malformed JSON and similar client errors are 4xx, not server faults
    if (err.status && err.status >= 400 && err.status < 500) {
      return res.status(err.status).json({ error: "Bad request" });
    }
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  });

  return app;
}
