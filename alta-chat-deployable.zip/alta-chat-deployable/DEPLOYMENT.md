# Alta Chat — deployment package

This folder is a monorepo with `frontend/` (React + Vite) and `backend/` (Node + Express + Socket.IO + MongoDB/Mongoose).

## 1. Put this source in GitHub

Extract this ZIP and upload/commit the contents of this folder to the root of the connected GitHub repository. The repository root must contain `backend/`, `frontend/`, `.gitignore`, and `render.yaml`.

Do not upload `.env` files. Only `.env.example` files belong in GitHub.

## 2. Deploy the backend on Render

Create a Render Web Service from the GitHub repository. Render can use the included `render.yaml`; otherwise use:

- Runtime: Node
- Region: Singapore
- Build command: `cd backend && npm install --no-audit --no-fund && npm run build`
- Start command: `cd backend && npm start`
- Health check path: `/health`

Set these values in Render's Environment tab (never paste secrets into GitHub or the frontend):

- `NODE_ENV=production`
- `MONGODB_URI` = MongoDB Atlas SRV URI for a **new empty database** and a least-privilege `readWrite` user
- `JWT_SECRET` = output of `openssl rand -base64 48` (must be at least 64 characters)
- `CLIENT_ORIGIN` = exact HTTPS origin of the deployed Vercel frontend, no trailing slash
- `BCRYPT_ROUNDS=12`
- `TRUST_PROXY=0`

The backend refuses to start without a valid TLS-enabled MongoDB URI and a sufficiently long JWT secret. Its `/health` route reports database state.

## 3. Deploy the frontend on Vercel

Import the same GitHub repository into the existing Vercel project and set:

- Framework preset: Vite
- Root directory: `frontend`
- Install command: `npm install --no-audit --no-fund`
- Build command: `npm run build`
- Output directory: `dist`

Add these Vercel environment variables for Production, Preview, and Development:

- `VITE_API_URL=https://YOUR-RENDER-SERVICE.onrender.com`
- `VITE_SOCKET_URL=https://YOUR-RENDER-SERVICE.onrender.com`

Use the exact public Render service origin with no trailing slash. Redeploy after adding the variables.

## 4. Connect the two services

After Vercel gives the frontend domain, set `CLIENT_ORIGIN` in Render to `https://YOUR-FRONTEND.vercel.app`, then redeploy the backend. Test:

- `https://YOUR-RENDER-SERVICE.onrender.com/health` → `status: ok`, `checks.database: up`
- Sign up, log in, create/join a room, send/receive messages, log out
- Verify real-time Socket.IO reconnects and cookies persist in the browser

## Important compatibility note

The app uses HttpOnly secure cookies for authentication and requires cross-origin credentialed requests. Browser privacy settings can block third-party cookies when the frontend is on `vercel.app` and the backend is on `onrender.com`. For reliable production login, use a custom frontend and API domain under the same registrable domain (for example `app.example.com` and `api.example.com`) and set `CLIENT_ORIGIN` to the custom frontend origin.

This E2EE build uses a new schema. Use a new empty MongoDB database; do not connect it to the old plaintext chat database. Configure Atlas network access securely; do not use `0.0.0.0/0` as a permanent allowlist.
