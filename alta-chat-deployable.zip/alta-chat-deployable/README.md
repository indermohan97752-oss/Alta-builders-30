# Alta Chat

End-to-end encrypted chat application source package.

- Frontend: React 18 + TypeScript + Vite (`frontend/`)
- Backend: Node.js + TypeScript + Express + Socket.IO + Mongoose (`backend/`)
- Database: MongoDB Atlas

See [`DEPLOYMENT.md`](./DEPLOYMENT.md) for the Render + Vercel deployment steps. Never commit secrets or real `.env` files.
